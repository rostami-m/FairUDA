import torch

import numpy as np

from config import config

def compute_accuracy(model, data, valid_columns=None, predict_sensitive=None, balanced=True, batch_size=512):
    model.eval()
    
    if predict_sensitive is None:
        all_xs = data.dataset.features[:, data.valid_columns]
        all_ys = data.dataset.labels.ravel()
    else:
        all_xs = data.dataset.features[:, data.valid_columns]
        all_ys = data.dataset.features[:, data.dataset.feature_names.index(predict_sensitive)].ravel()
    
    acc = 0
    acc0 = 0
    acc1 = 0
    idx = 0
    while idx < all_xs.shape[0]:
        x_curr, y_curr = torch.tensor(all_xs[idx:idx+batch_size]), torch.tensor(all_ys[idx:idx+batch_size])
        x_curr = torch.autograd.Variable(x_curr).to(config["device"]).float()
        y_curr = torch.autograd.Variable(y_curr).long()

        with torch.no_grad():
            y_hat = model(x_curr).clone().detach().cpu()

            if balanced == True:
                acc0 = acc0 + torch.sum((torch.argmax(y_hat, axis=-1) == y_curr) & (y_curr == 0))
                acc1 = acc1 + torch.sum((torch.argmax(y_hat, axis=-1) == y_curr) & (y_curr == 1))
            else:
                acc = acc + torch.sum(torch.argmax(y_hat, axis=-1) == y_curr)

        idx += batch_size

    if balanced == True:
        acc = (acc0 / np.sum(all_ys == 0) + acc1 / np.sum(all_ys == 1)) / 2
    else:
        acc = acc / all_xs.shape[0]
    
    return acc