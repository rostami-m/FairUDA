def split(df, type):
	if type == 'standard':
		train_data = df.sample(frac = 0.7)
		test_data = df.drop(train_data.index)
	elif type == 'race':
		df_idx = df['race'] == 1
		train_data = df[df_idx].copy()
		test_data = df[~df_idx].copy()
	elif type == 'education':
		df_idx = df['Education Years=>12'] == 1
		train_data = df[~df_idx].copy()
		test_data = df[df_idx].copy()
	elif type == 'age':
		df_idx = (df['Age (decade)=10'] == 1) | (df['Age (decade)=20'] == 1)
		train_data = df[~df_idx].copy()
		test_data = df[df_idx].copy()
	return train_data, test_data