import torch
import random

class MyDataset(torch.utils.data.Dataset):
    def __init__(self, aif_dataset, target, sensitive):
        self.dataset = aif_dataset
        self.target = target
        self.sensitive = sensitive
        self.valid_columns = [self.dataset.feature_names.index(x) \
                         for x in self.dataset.feature_names]

    def __len__(self):
        return self.dataset.features.shape[0]

    def sample(self, batch_size, return_sensitive = False):
        assert self.__len__() >= batch_size

        idx = random.sample(range(self.__len__()), batch_size)
        
        if return_sensitive == False:
            return self.dataset.features[idx][:, self.valid_columns], \
                self.dataset.labels[idx].ravel()
        else:
            return self.dataset.features[idx][:, self.valid_columns], \
                self.dataset.labels[idx].ravel(), \
                self.dataset.features[idx][:, self.dataset.feature_names.index(self.sensitive)].ravel()