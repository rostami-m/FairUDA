import torch
from config import config

# Create predictions dataframe
def create_predictions_dataframe(model, data, batch_size=512):
    model.eval()
    
    ret = data.dataset.convert_to_dataframe()[0].copy()
    
    all_xs = data.dataset.features[:, data.valid_columns]
    all_ys = data.dataset.labels.ravel()
    idx = 0
    while idx < all_xs.shape[0]:
        x_curr, y_curr = torch.tensor(all_xs[idx:idx+batch_size]), torch.tensor(all_ys[idx:idx+batch_size])
        x_curr = torch.autograd.Variable(x_curr).to(config["device"]).float()
        y_curr = torch.autograd.Variable(y_curr).to(config["device"]).long()
    
        with torch.no_grad():
            y_hat = model(x_curr).clone().detach()
        
        ret.iloc[idx:idx+batch_size, -1] = torch.argmax(y_hat, axis=-1).cpu().numpy()

        idx += batch_size
    
    return ret