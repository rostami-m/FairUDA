def get_predictions(model, train_data, test_data):
    pred_train = create_predictions_dataframe(classifier, train_data)
    pred_test = create_predictions_dataframe(classifier, test_data)
    print("Train accuracy =", (pred_train["Income Binary"] == train_data.dataset.labels.ravel()).sum() / len(pred_train))
    print("Test accuracy =", (pred_test["Income Binary"] == test_data.dataset.labels.ravel()).sum() / len(pred_test))

    # Turn the predictions dataframe into AIF360 format, and print metrics
    dataset_nn_pred_train = StandardDataset(pred_train, \
                   label_name='Income Binary', \
                   favorable_classes=[1], \
                   protected_attribute_names = ['sex', 'race'], \
                   privileged_classes = [])
    dataset_nn_pred_test = StandardDataset(pred_test, \
                   label_name='Income Binary', \
                   favorable_classes=[1], \
                   protected_attribute_names = ['sex', 'race'], \
                   privileged_classes = [])

    ######################################################################################################################################################

    display(Markdown("#### Dataset - dataset metrics"))
    metric_scaled_train = BinaryLabelDatasetMetric(train_data.dataset,
                             unprivileged_groups=unprivileged_groups,
                             privileged_groups=privileged_groups)
    metric_scaled_test = BinaryLabelDatasetMetric(test_data.dataset, 
                             unprivileged_groups=unprivileged_groups,
                             privileged_groups=privileged_groups)
    print("Train set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_scaled_train.mean_difference())
    print("Test set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_scaled_test.mean_difference())

    display(Markdown("#### Model - dataset metrics"))
    metric_dataset_debiasing_train = BinaryLabelDatasetMetric(dataset_nn_pred_train, 
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)
    metric_dataset_debiasing_test = BinaryLabelDatasetMetric(dataset_nn_pred_test, 
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)
    print("Train set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_dataset_debiasing_train.mean_difference())
    print("Test set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_dataset_debiasing_test.mean_difference())

    display(Markdown("#### Model - neural network - classification metrics - training"))
    classified_metric_nn_train = ClassificationMetric(train_data.dataset, 
                                                     dataset_nn_pred_train,
                                                     unprivileged_groups=unprivileged_groups,
                                                     privileged_groups=privileged_groups)
    print("Train set: Classification accuracy = %f" % classified_metric_nn_train.accuracy())
    TPR = classified_metric_nn_train.true_positive_rate()
    TNR = classified_metric_nn_train.true_negative_rate()
    bal_acc_debiasing_test = 0.5*(TPR+TNR)
    print("Train set: Balanced classification accuracy = %f" % bal_acc_debiasing_test)
    print("Train set: Disparate impact = %f" % classified_metric_nn_train.disparate_impact())
    print("Train set: Equal opportunity difference = %f" % classified_metric_nn_train.equal_opportunity_difference())
    print("Train set: Average odds difference = %f" % classified_metric_nn_train.average_odds_difference())
    print("Train set: Theil_index = %f" % classified_metric_nn_train.theil_index())

    display(Markdown("#### Model - neural network - classification metrics - test"))
    classified_metric_nn_test = ClassificationMetric(test_data.dataset, 
                                                     dataset_nn_pred_test,
                                                     unprivileged_groups=unprivileged_groups,
                                                     privileged_groups=privileged_groups)
    print("Test set: Classification accuracy = %f" % classified_metric_nn_test.accuracy())
    TPR = classified_metric_nn_test.true_positive_rate()
    TNR = classified_metric_nn_test.true_negative_rate()
    bal_acc_debiasing_test = 0.5*(TPR+TNR)
    print("Test set: Balanced classification accuracy = %f" % bal_acc_debiasing_test)
    print("Test set: Disparate impact = %f" % classified_metric_nn_test.disparate_impact())
    print("Test set: Equal opportunity difference = %f" % classified_metric_nn_test.equal_opportunity_difference())
    print("Test set: Average odds difference = %f" % classified_metric_nn_test.average_odds_difference())
    print("Test set: Theil_index = %f" % classified_metric_nn_test.theil_index())