# import sys
# sys.path.append("../src")
# # sys.path.append("../../src")
# from config import config

from aif360.datasets import StandardDataset
from aif360.metrics import ClassificationMetric

from aif360.algorithms.inprocessing.exponentiated_gradient_reduction import ExponentiatedGradientReduction
from aif360.algorithms.postprocessing.reject_option_classification import RejectOptionClassification
from aif360.algorithms.inprocessing.adversarial_debiasing import AdversarialDebiasing
from aif360.algorithms.inprocessing import MetaFairClassifier

from aif360.metrics import ClassificationMetric, BinaryLabelDatasetMetric

from sampling_dataset import MyDataset
from utils import create_predictions_dataframe
# from config import config
from metrics import compute_accuracy
from fairness_metrics import demographic_parity_difference
# from data_tools import split
import wasserstein_utils

import torch
import torch.nn as nn

import tensorflow.compat.v1 as tf
tf.disable_eager_execution()

# from common_utils import compute_metrics

import numpy as np
import copy

from sklearn.linear_model import LogisticRegression

class FairAlgorithms:
    def __init__(self, name, train_data, val_data, test_data, eval_data, privileged_groups, unprivileged_groups, config):
        self.config              = config
        self.data                = {}
        self.name                = name
        self.data['train']       = train_data.copy(deepcopy=True)
        self.data['val']         = val_data.copy(deepcopy=True)
        self.data['test']        = test_data.copy(deepcopy=True)
        self.data['eval']        = eval_data.copy(deepcopy=True)
        self.bkp_data            = {k : self.data[k].copy(deepcopy=True) for k in self.data}
        self.privileged_groups   = privileged_groups.copy()
        self.unprivileged_groups = unprivileged_groups.copy()

    def scale_dataset(self, scaler):
        if scaler is None:
            return

        scaler.fit(self.data['train'].features)
        for k in self.data:
            self.data[k].features = scaler.transform(self.data[k].features)

    def cleanup(self):
        # Revert datasets to original form
        for k in self.data:
            self.data[k] = self.bkp_data[k].copy(deepcopy=True)

    def run_egr(self, scaler=None, constraints='EqualizedOdds', seed = 0):
        '''
        A function that runs the Exponetited gradient reduction algorithm
        '''
        self.scale_dataset(scaler)

        estimator = LogisticRegression(solver='lbfgs', max_iter=1000)
        np.random.seed(seed) #need for reproducibility
        exp_grad_red = ExponentiatedGradientReduction(estimator=estimator, 
                                                      constraints=constraints,
                                                      drop_prot_attr=False)
        exp_grad_red.fit(self.data['train'])
        exp_grad_red_pred = exp_grad_red.predict(self.data['eval'])

        metrics = ClassificationMetric(self.data['eval'], 
                    exp_grad_red_pred,
                    unprivileged_groups=self.unprivileged_groups,
                    privileged_groups=self.privileged_groups)

        TPR = metrics.true_positive_rate()
        TNR = metrics.true_negative_rate()
        bal_acc = 0.5*(TPR+TNR)

        res = {}
        res['name'] = 'ExponentiatedGradientReduction'
        res['accuracy'] = metrics.accuracy()
        res['bal_accuracy'] = bal_acc
        res['disparate_impact_delta'] = metrics.mean_difference()
        res['disparate_impact_ratio'] = metrics.disparate_impact()
        res['equal_opportunity_delta'] = metrics.equal_opportunity_difference()
        res['average_odds_delta'] = metrics.average_odds_difference()

        self.cleanup()

        return res

    def run_roc(self, scaler=None, metric_name='Statistical parity difference', metric_ub = 0.05, metric_lb = -0.05, seed = 0, use_accuracy=False):
        '''
        A function that runs the reject option classifier

        metric_ub, metric_lb - Upper and lower bound on the fairness metric used
        use_accuracy - if true, optimizes for accuracy, if false, optimizes for balanced accuracy
        '''
        self.scale_dataset(scaler)

        # Verify metric name
        allowed_metrics = ["Statistical parity difference",
                           "Average odds difference",
                           "Equal opportunity difference"]
        if metric_name not in allowed_metrics:
            raise ValueError("Metric name should be one of allowed metrics")

        #random seed for calibrated equal odds prediction
        np.random.seed(seed)

        lmod = LogisticRegression()
        lmod.fit(self.data['train'].features, self.data['train'].labels)

        # positive class index
        pos_ind = np.where(lmod.classes_ == self.data['train'].favorable_label)[0][0]

        # get validation and target predictions
        dataset_orig_valid_pred = self.data['val'].copy(deepcopy=True)
        dataset_orig_valid_pred.scores = lmod.predict_proba(self.data['val'].features)[:,pos_ind].reshape(-1,1)

        dataset_orig_test_pred = self.data['eval'].copy(deepcopy=True)
        dataset_orig_test_pred.scores = lmod.predict_proba(self.data['eval'].features)[:,pos_ind].reshape(-1,1)

        # Get the best threshold for classifcation only (no fairness)
        num_thresh = 100
        ba_arr = np.zeros(num_thresh)
        class_thresh_arr = np.linspace(0.01, 0.99, num_thresh)
        for idx, class_thresh in enumerate(class_thresh_arr):
            fav_inds = dataset_orig_valid_pred.scores > class_thresh
            dataset_orig_valid_pred.labels[fav_inds] = dataset_orig_valid_pred.favorable_label
            dataset_orig_valid_pred.labels[~fav_inds] = dataset_orig_valid_pred.unfavorable_label
            
            classified_metric_orig_valid = ClassificationMetric(self.data['val'],
                                                     dataset_orig_valid_pred, 
                                                     unprivileged_groups=self.unprivileged_groups,
                                                     privileged_groups=self.privileged_groups)
            
            if use_accuracy == False:
                ba_arr[idx] = 0.5*(classified_metric_orig_valid.true_positive_rate()\
                                   +classified_metric_orig_valid.true_negative_rate())
            else:
                ba_arr[idx] = classified_metric_orig_valid.accuracy()

        best_ind = np.where(ba_arr == np.max(ba_arr))[0][0]
        best_class_thresh = class_thresh_arr[best_ind]

        # print("Best balanced accuracy (no fairness constraints) = %.4f" % np.max(ba_arr))
        # print("Optimal classification threshold (no fairness constraints) = %.4f" % best_class_thresh)


        ROC = RejectOptionClassification(unprivileged_groups=self.unprivileged_groups, 
                                        privileged_groups=self.privileged_groups, 
                                        low_class_thresh=0.01, high_class_thresh=0.99,
                                        num_class_thresh=100, num_ROC_margin=50,
                                        metric_name=metric_name,
                                        metric_ub=metric_ub, metric_lb=metric_lb)
        ROC = ROC.fit(self.data['val'], dataset_orig_valid_pred)

        # Metrics for the test set
        fav_inds = dataset_orig_test_pred.scores > best_class_thresh
        dataset_orig_test_pred.labels[fav_inds] = dataset_orig_test_pred.favorable_label
        dataset_orig_test_pred.labels[~fav_inds] = dataset_orig_test_pred.unfavorable_label

        # Metrics for the transformed test set
        dataset_transf_test_pred = ROC.predict(dataset_orig_test_pred)

        metrics = ClassificationMetric(self.data['eval'], 
                    dataset_transf_test_pred,
                    unprivileged_groups=self.unprivileged_groups,
                    privileged_groups=self.privileged_groups)

        TPR = metrics.true_positive_rate()
        TNR = metrics.true_negative_rate()
        bal_acc = 0.5*(TPR+TNR)

        res = {}
        res['name'] = 'RejectOptionClassifier'
        res['accuracy'] = metrics.accuracy()
        res['bal_accuracy'] = bal_acc
        res['disparate_impact_delta'] = metrics.mean_difference()
        res['disparate_impact_ratio'] = metrics.disparate_impact()
        res['equal_opportunity_delta'] = metrics.equal_opportunity_difference()
        res['average_odds_delta'] = metrics.average_odds_difference()

        self.cleanup()

        return res

    def run_advdeb(self, scaler=None):
        self.scale_dataset(scaler)

        tf.reset_default_graph()
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.5)
        sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
        debiased_model = AdversarialDebiasing(privileged_groups = self.privileged_groups,
                                  unprivileged_groups = self.unprivileged_groups,
                                  scope_name='debiased_classifier',
                                  debias=True,
                                  sess=sess)
        debiased_model.fit(self.data["train"])
        dataset_debiasing_test = debiased_model.predict(self.data["eval"])

        sess.close()

        metrics = ClassificationMetric(self.data['eval'], 
                    dataset_debiasing_test,
                    unprivileged_groups=self.unprivileged_groups,
                    privileged_groups=self.privileged_groups)

        TPR = metrics.true_positive_rate()
        TNR = metrics.true_negative_rate()
        bal_acc = 0.5*(TPR+TNR)

        res = {}
        res['name'] = 'AdversarialDebiasing'
        res['accuracy'] = metrics.accuracy()
        res['bal_accuracy'] = bal_acc
        res['disparate_impact_delta'] = metrics.mean_difference()
        res['disparate_impact_ratio'] = metrics.disparate_impact()
        res['equal_opportunity_delta'] = metrics.equal_opportunity_difference()
        res['average_odds_delta'] = metrics.average_odds_difference()

        self.cleanup()

        return res

    def run_metacls(self, scaler=None):
        self.scale_dataset(scaler)

        sensitive_attr = list(self.privileged_groups[0].keys())[0]

        debiased_model = MetaFairClassifier(tau=0.7, sensitive_attr=sensitive_attr, type="fdr").fit(self.data['train'])
        dataset_debiasing_test = debiased_model.predict(self.data['eval'])

        metrics = ClassificationMetric(self.data['eval'], 
                    dataset_debiasing_test,
                    unprivileged_groups=self.unprivileged_groups,
                    privileged_groups=self.privileged_groups)

        TPR = metrics.true_positive_rate()
        TNR = metrics.true_negative_rate()
        bal_acc = 0.5*(TPR+TNR)

        res = {}
        res['name'] = 'MetaClassifier'
        res['accuracy'] = metrics.accuracy()
        res['bal_accuracy'] = bal_acc
        res['disparate_impact_delta'] = metrics.mean_difference()
        res['disparate_impact_ratio'] = metrics.disparate_impact()
        res['equal_opportunity_delta'] = metrics.equal_opportunity_difference()
        res['average_odds_delta'] = metrics.average_odds_difference()

        self.cleanup()

        return res

    def run_fairadapt(self, scaler=None, start_position=0, preloaded_weights=None):
        self.scale_dataset(scaler)

        train_data = MyDataset(self.data['train'].copy(deepcopy=True), self.config[self.name]['target'], self.config[self.name]["sensitive"])
        val_data   = MyDataset(self.data['val'].copy(deepcopy=True), self.config[self.name]['target'], self.config[self.name]["sensitive"])
        test_data  = MyDataset(self.data['test'].copy(deepcopy=True), self.config[self.name]['target'], self.config[self.name]["sensitive"])
        eval_data  = MyDataset(self.data['eval'].copy(deepcopy=True), self.config[self.name]['target'], self.config[self.name]["sensitive"])

        # Create a network
        encoder = nn.Sequential(
            nn.Linear(self.data['train'].features.shape[1],20),
            nn.BatchNorm1d(20),
            nn.ReLU(inplace=True),
        ).to(self.config['device'])

        # Classification network
        classifier = nn.Sequential(
            encoder, 
            nn.Linear(20,2)).to(self.config['device'])

        # Fairness network
        classifier_sensitive = nn.Sequential(
            encoder,
            nn.Linear(20,2)).to(self.config['device'])

        if preloaded_weights is not None:
            classifier.load_state_dict(preloaded_weights[0])
            classifier_sensitive.load_state_dict(preloaded_weights[1])

        # Train the model (no fairness constraints)
        optim_cls      = torch.optim.Adam(params = [{'params':list(classifier.parameters()), 'lr':self.config[self.name]["lr"], 'weight_decay':1e-2}])
        optim_sens_min = torch.optim.Adam(params = [{'params':list(classifier_sensitive.parameters())[-2:], 'lr':self.config[self.name]["lr"], 'weight_decay':1e-2}])
        optim_sens_max = torch.optim.Adam(params = [{'params':encoder.parameters(), 'lr':self.config[self.name]["lr"], 'weight_decay':1e-2}])
        optim_adapt    = torch.optim.Adam(params = [{'params':encoder.parameters(), 'lr':self.config[self.name]["lr_adapt"], 'weight_decay':1e-2}])

        classifier.train()
        classifier_sensitive.train()

        num_training_epochs = self.config[self.name]["num_epochs"]
        batch_size = self.config[self.name]["batch_size"]

        # Source label weights
        weights = 1 - np.unique(train_data.dataset.labels, return_counts=True)[1] / train_data.dataset.features.shape[0]
        if self.config[self.name]["weighted_loss"] == False:
            weights = np.ones(len(weights))
        weights = torch.FloatTensor(weights).to(self.config['device'])

        # Source sensitive attribute weights
        weights_a = 1 - np.unique(train_data.dataset.convert_to_dataframe()[0][self.config[self.name]["sensitive"]], \
                                  return_counts=True)[1] / train_data.dataset.features.shape[0]
        if self.config[self.name]["weighted_loss"] == False:
            weights_a = np.ones(len(weights_a))
        weights_a = torch.FloatTensor(weights_a).to(self.config['device'])

        # Target sensitive attribute weights
        weights_a_tar = 1 - np.unique(test_data.dataset.convert_to_dataframe()[0][self.config[self.name]["sensitive"]], \
                                  return_counts=True)[1] / test_data.dataset.features.shape[0]
        if self.config[self.name]["weighted_loss"] == False:
            weights_a_tar = np.ones(len(weights_a_tar))
        weights_a_tar = torch.FloatTensor(weights_a_tar).to(self.config['device'])

        save_data_test = {}
        save_data_eval = {}
        for metric in ['accuracy', 'bal-accuracy', 'disp-impact', 'eo-diff', 'ao-diff']:
            save_data_test[metric] = []
            save_data_eval[metric] = []

        best_value = -1e10
        best_cls   = copy.deepcopy(classifier)
        best_fair  = copy.deepcopy(classifier_sensitive)

        before_adapt_cls      = None
        before_adapt_cls_sens = None
        adapt_start = min(self.config[self.name]['start_tar_fairness'], self.config[self.name]['start_adaptation'])
        for epoch in range(start_position, num_training_epochs):
            if epoch == adapt_start:
                before_adapt_cls = copy.deepcopy(classifier.state_dict())
                before_adapt_cls_sens = copy.deepcopy(classifier_sensitive.state_dict())

            classifier.train()
            classifier_sensitive.train()
            
            # Load in the data
            x_src, y_src, a_src = train_data.sample(batch_size, return_sensitive=True)
            x_src, y_src, a_src = torch.tensor(x_src), torch.tensor(y_src), torch.tensor(a_src)
            x_src               = torch.autograd.Variable(x_src).to(self.config['device']).float()
            y_src               = torch.autograd.Variable(y_src).to(self.config['device']).long()
            a_src               = torch.autograd.Variable(a_src).to(self.config['device']).long()
            
            x_tar, _, a_tar     = test_data.sample(batch_size, return_sensitive=True)
            x_tar, a_tar        = torch.tensor(x_tar), torch.tensor(a_tar)
            x_tar               = torch.autograd.Variable(x_tar).to(self.config['device']).float()
            a_tar               = torch.autograd.Variable(a_tar).to(self.config['device']).long()

            if epoch % 3 == 0:
                # CE loss
                optim_cls.zero_grad()
                y_hat = classifier(x_src)
                loss_cls = nn.CrossEntropyLoss(weights)(y_hat, y_src)
                loss_cls.backward()
                optim_cls.step()
                
            elif epoch % 3 == 1:
                if self.config[self.name]["use_src_fairness"] == True and epoch >= self.config[self.name]["start_src_fairness"]:
                    # Sensitive attr loss
                    optim_sens_min.zero_grad()
                    a_hat = classifier_sensitive(x_src)
                    loss_sens = nn.CrossEntropyLoss(weights_a)(a_hat, a_src) 
                    loss_sens.backward()
                    optim_sens_min.step()
                    # if epoch % 100 == 0:
                    #     print("!")
                    
                if self.config[self.name]["use_tar_fairness"] == True and epoch >= self.config[self.name]["start_tar_fairness"]:
                    optim_sens_min.zero_grad()
                    a_hat_tar = classifier_sensitive(x_tar)
                    loss_sens = nn.CrossEntropyLoss(weights_a_tar)(a_hat_tar, a_tar) 
                    loss_sens.backward()
                    optim_sens_min.step()
                    # if epoch % 100 == 0:
                    #     print("!!!")
            else:
                if self.config[self.name]["use_src_fairness"] == True and epoch >= self.config[self.name]["start_src_fairness"]:
                    # Sensitive adv. loss
                    optim_sens_max.zero_grad()
                    a_hat = classifier_sensitive(x_src)
                    loss_adv = -nn.CrossEntropyLoss(weights_a)(a_hat, a_src)
                    loss_adv.backward()
                    optim_sens_max.step()
                
                if self.config[self.name]["use_tar_fairness"] == True and epoch >= self.config[self.name]["start_tar_fairness"]:
                    optim_sens_max.zero_grad()
                    a_hat_tar = classifier_sensitive(x_tar)
                    loss_adv = -nn.CrossEntropyLoss(weights_a_tar)(a_hat_tar, a_tar)
                    loss_adv.backward()
                    optim_sens_max.step()
                
            # Domain adaptation loss
            if self.config[self.name]["use_adaptation"] == True and epoch >= self.config[self.name]["start_adaptation"]:
                optim_adapt.zero_grad()
                loss_adapt = self.config[self.name]["gamma"] * wasserstein_utils.sliced_wasserstein_distance(encoder(x_src), encoder(x_tar), device=self.config["device"])
                loss_adapt.backward()
                optim_adapt.step()
            
            with torch.no_grad():
                if epoch % (num_training_epochs // self.config[self.name]["num_evaluations"]) == 0 or (epoch == num_training_epochs - 1):
                    # Create prediction dataframes
                    pred_test = create_predictions_dataframe(classifier, test_data)
                    pred_eval = create_predictions_dataframe(classifier, eval_data)
                    dataset_nn_pred_test = StandardDataset(pred_test, \
                       label_name=self.config[self.name]['target'], \
                       favorable_classes=[1], \
                       protected_attribute_names = self.config[self.name]['protected'], \
                       privileged_classes = [])
                    dataset_nn_pred_eval = StandardDataset(pred_eval, \
                       label_name=self.config[self.name]['target'], \
                       favorable_classes=[1], \
                       protected_attribute_names = self.config[self.name]['protected'], \
                       privileged_classes = [])
                    
                    metric_model_debiasing_test = BinaryLabelDatasetMetric(dataset_nn_pred_test, 
                                                     unprivileged_groups=self.unprivileged_groups,
                                                     privileged_groups=self.privileged_groups)
                    metric_model_debiasing_eval = BinaryLabelDatasetMetric(dataset_nn_pred_eval, 
                                                     unprivileged_groups=self.unprivileged_groups,
                                                     privileged_groups=self.privileged_groups)
                    
                    # Stats for printing
                    acc_train     = compute_accuracy(classifier, train_data)
                    acc_val       = compute_accuracy(classifier, val_data)
                    acc_test      = compute_accuracy(classifier, test_data)
                    acc_eval      = compute_accuracy(classifier, eval_data)

                    acc_sensitive_train     = compute_accuracy(classifier_sensitive, train_data, self.config[self.name]["sensitive"])
                    acc_sensitive_val       = compute_accuracy(classifier_sensitive, val_data, self.config[self.name]["sensitive"])
                    acc_sensitive_test      = compute_accuracy(classifier_sensitive, test_data, self.config[self.name]["sensitive"])
                    acc_sensitive_eval      = compute_accuracy(classifier_sensitive, eval_data, self.config[self.name]["sensitive"])

                    pred_train       = create_predictions_dataframe(classifier, train_data)
                    pred_val         = create_predictions_dataframe(classifier, val_data)
                    pred_test        = create_predictions_dataframe(classifier, test_data)
                    pred_eval        = create_predictions_dataframe(classifier, eval_data)
                    dp               = demographic_parity_difference(pred_train, self.config[self.name]["sensitive"], self.config[self.name]['target'])
                    dp_val           = demographic_parity_difference(pred_val, self.config[self.name]["sensitive"], self.config[self.name]['target'])
                    dp_test          = demographic_parity_difference(pred_test, self.config[self.name]["sensitive"], self.config[self.name]['target'])
                    dp_eval          = demographic_parity_difference(pred_eval, self.config[self.name]["sensitive"], self.config[self.name]['target'])

                    if epoch % 1000 == 0:
                        print('It. {}, \
                            SrcA = {:.2f}, ValA = {:.2f}, TarA = {:.2f}, EvalA = {:.2f}\
                            SrcDP = {:.2f}, ValDP = {:.2f}, TarDP = {:.2f}, EvalDP = {:.2f}'.format(epoch, 
                                                              acc_train, acc_val, acc_test, acc_eval,
                                                              dp, dp_val, dp_test, dp_eval))
                    
                    if acc_val - np.abs(dp_test) > best_value and epoch > (adapt_start + num_training_epochs) // 2:
                        # Do not save degenerate solutions
                        yhat_counts = np.unique(pred_test[self.config[self.name]['target']].values, return_counts=True)[1]
                        assert len(yhat_counts) <= 2
                        if len(yhat_counts) == 2:
                            best_value = acc_val - np.abs(dp_test)
                            best_cls   = copy.deepcopy(classifier)
                            best_fair  = copy.deepcopy(classifier_sensitive)

                            if epoch % 1000 != 0:
                                print('It. {}, \
                                    SrcA = {:.2f}, ValA = {:.2f}, TarA = {:.2f}, EvalA = {:.2f}\
                                    SrcDP = {:.2f}, ValDP = {:.2f}, TarDP = {:.2f}, EvalDP = {:.2f}'.format(epoch, 
                                                                      acc_train, acc_val, acc_test, acc_eval,
                                                                      dp, dp_val, dp_test, dp_eval))
                            print('Saved model')


        # Create metrics
        pred_eval = create_predictions_dataframe(best_cls, eval_data)
        dataset_nn_pred_eval = StandardDataset(pred_eval, \
            label_name=self.config[self.name]['target'], \
            favorable_classes=[1], \
            protected_attribute_names = self.config[self.name]['protected'], \
            privileged_classes = [])

        metrics = ClassificationMetric(eval_data.dataset, 
            dataset_nn_pred_eval,
            unprivileged_groups=self.unprivileged_groups,
            privileged_groups=self.privileged_groups)

        TPR = metrics.true_positive_rate()
        TNR = metrics.true_negative_rate()
        bal_acc = 0.5*(TPR+TNR)

        res = {}
        res['name'] = 'FairTransferClassifier'
        res['accuracy'] = metrics.accuracy()
        res['bal_accuracy'] = bal_acc
        res['disparate_impact_delta'] = metrics.mean_difference()
        res['disparate_impact_ratio'] = metrics.disparate_impact()
        res['equal_opportunity_delta'] = metrics.equal_opportunity_difference()
        res['average_odds_delta'] = metrics.average_odds_difference()

        self.cleanup()

        return res, before_adapt_cls, before_adapt_cls_sens
