import numpy as np

def demographic_parity_ratio(df, sensitive, target):
    # 0 - unpriviledged, 1 - priviledged
    return (np.sum(df[df[sensitive] == 0][target]) / df[df[sensitive] == 0].shape[0]) /\
            (np.sum(df[df[sensitive] == 1][target]) / df[df[sensitive] == 1].shape[0])

def demographic_parity_difference(df, sensitive, target):
    # 0 - unpriviledged, 1 - priviledged
    return (np.sum(df[df[sensitive] == 0][target]) / df[df[sensitive] == 0].shape[0]) -\
            (np.sum(df[df[sensitive] == 1][target]) / df[df[sensitive] == 1].shape[0])