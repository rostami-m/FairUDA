import numpy as np

config = {}

config["gpu"]                       = 0
config["device"]                    = 'cuda:' + str(config['gpu']) if config["gpu"] >= 0 else "cpu"

config["adult"]                     = {}
config["german"]                    = {}
config["compas"]                    = {}

config["adult"]["protected"]        = ["sex", "race"]
config["adult"]["sensitive"]        = "sex"
config["adult"]["target"]           = "Income Binary"

config["german"]["protected"]       = ["sex", "age"]
config["german"]["sensitive"]       = "age"
config["german"]["target"]          = "credit"

config["compas"]["protected"]       = ["sex", "race"]
config["compas"]["sensitive"]       = "sex"
config["compas"]["target"]          = "two_year_recid"


# Regularizers 
config["adult"]["gamma"]                     = 1
config["compas"]["gamma"]                    = 1
config["german"]["gamma"]                    = 1


config["adult"]['weighted_loss']             = True
config["adult"]["train_ratio"]               = .7
config["adult"]["out_file"]                  = "output_adult.txt"
config["adult"]["num_epochs"]                = 45000
config["adult"]["start_adaptation"]          = 30000
config["adult"]["start_src_fairness"]        = 15000
config["adult"]["start_tar_fairness"]        = 30000
config["adult"]["batch_size"]                = 64
config["adult"]["lr"]                        = 1e-4
config["adult"]["lr_adapt"]                  = config["adult"]["lr"] * 1e-1
config["adult"]["num_evaluations"]           = 4500
config["adult"]["use_src_fairness"]          = True
config["adult"]["use_tar_fairness"]          = True
config["adult"]["use_adaptation"]            = True


config["compas"]['weighted_loss']             = True
config["compas"]["train_ratio"]               = .7
config["compas"]["out_file"]                  = "output_compas.txt"
config["compas"]["num_epochs"]                = 45000
config["compas"]["start_adaptation"]          = 30000
config["compas"]["start_src_fairness"]        = 15000
config["compas"]["start_tar_fairness"]        = 30000
config["compas"]["batch_size"]                = 32
config["compas"]["lr"]                        = 1e-4
config["compas"]["lr_adapt"]                  = config["compas"]["lr"] * 1e-1
config["compas"]["num_evaluations"]           = 4500
config["compas"]["use_src_fairness"]          = True
config["compas"]["use_tar_fairness"]          = True
config["compas"]["use_adaptation"]            = True


config["german"]['weighted_loss']             = True
config["german"]["train_ratio"]               = .7
config["german"]["out_file"]                  = "output_german.txt"
config["german"]["num_epochs"]                = 45000
config["german"]["start_adaptation"]          = 30000
config["german"]["start_src_fairness"]        = 15000
config["german"]["start_tar_fairness"]        = 30000
config["german"]["batch_size"]                = 64
config["german"]["lr"]                        = 1e-4
config["german"]["lr_adapt"]                  = config["german"]["lr"] * 1e-1
config["german"]["num_evaluations"]           = 4500
config["german"]["use_src_fairness"]          = False
config["german"]["use_tar_fairness"]          = False
config["german"]["use_adaptation"]            = False