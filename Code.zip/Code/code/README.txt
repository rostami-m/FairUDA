Before running the notebook, installation of the AIF360 repository is required.

Model selection is done based on validation accuracy and target demographic parity.